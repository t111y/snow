public class TestUser4 extends TestUser {
    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    private int b=999;
    public int find1(){
        return 1;
    }
}
