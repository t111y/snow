import org.junit.jupiter.api.Test;

public class TestLong {
    @Test
    public void testLong(){
        long l = 109;
        long l1 = l/10;
        System.out.println(l1);
    }
}
