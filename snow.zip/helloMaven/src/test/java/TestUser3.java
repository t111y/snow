public class TestUser3 extends TestUser {
    public int getBb() {
        return bb;
    }

    private int bb=999;
    public int find1(){
        return 1;
    }
}
