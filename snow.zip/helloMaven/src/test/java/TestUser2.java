public class TestUser2 extends TestUser {
    private int bb = 99;
    public int find1(){
        return 1;
    }
}
