import org.junit.jupiter.api.Test;
import top.yaovan.mysql.ParseAnnotation;

public class TestMysql {
    @Test
    public void testMysql(){
        ParseAnnotation parseAnnotation = new ParseAnnotation();
//        parseAnnotation.parseMethod();
    }
}
