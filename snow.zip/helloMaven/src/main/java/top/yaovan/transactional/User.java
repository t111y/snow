package top.yaovan.transactional;

import java.io.Serializable;

public class User {
    public int b = 2;
    public int a = 1;
}
