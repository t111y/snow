declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class ButtonSkinGreenSkin extends eui.Skin{
}
declare class ButtonSkinRedSkin extends eui.Skin{
}
declare class RockerBarSkin extends eui.Skin{
}
declare class AlertWindowSkin extends eui.Skin{
}
declare class GameMainLoaderWindowSkin extends eui.Skin{
}
declare class LogWindowSkin extends eui.Skin{
}
declare class TopToolBarSkin extends eui.Skin{
}
