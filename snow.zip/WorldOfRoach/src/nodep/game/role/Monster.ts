class Monster extends FocusRole{
	public constructor() {
		super();
	}
}