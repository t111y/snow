/**
 * 横向布局容器
 * @author nodep
 * @version 1.0
 */
class HBox {
	public constructor() {
	}
}