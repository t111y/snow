/**
 * 纵向布局容器
 * @author nodep
 * @version 1.0
 */
class VBox {
	public constructor() {
	}
}