/**
 * 焦点对象
 * @author nodep
 * @version 1.0
 */
interface IFocus {
	setFocus(flag:boolean);
}