/**
 * 日志输出
 * @author nodep
 * @version 1.0
 */
class LogTrace {
	public static log(str:string):void
	{
		console.log(str);
	}
}