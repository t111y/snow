class WindowType {
	public static ALERT_WIN:string = "ALERT_WIN";
}