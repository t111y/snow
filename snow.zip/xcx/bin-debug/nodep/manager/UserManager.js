var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var UserManager = (function () {
    function UserManager() {
        Globals.i().net.addEventListener(MessageType.sc_userEnter + "", this.onUserEnter, this);
        Globals.i().net.addEventListener(MessageType.sc_circlePath + "", this.onCirclePath, this);
        Globals.i().net.addEventListener(MessageType.sc_move + "", this.onMove, this);
    }
    UserManager.prototype.onUserEnter = function (e) {
        var msg = e.data;
        for (var i = 0; i < msg.players.length; i++) {
            var role = Tiled_Ground.getIns().getUserRole(msg.players[i]);
            if (role == null) {
                role = new UserRole();
                role.name = msg.players[i];
                Tiled_Ground.getIns().addFocusRole(role);
            }
        }
    };
    UserManager.prototype.onCirclePath = function (e) {
        var msg = e.data;
        var role = Tiled_Ground.getIns().getUserRole(msg.playerId);
        var mesh = new RoleMesh();
        mesh.addPoints(msg.circlePath);
        mesh.time = msg.time;
        role.roleMeshs.push(mesh);
    };
    UserManager.prototype.onMove = function (e) {
        var msg = e.data;
        var role = Tiled_Ground.getIns().getUserRole(msg.playerId);
        role.path = role.path.concat(msg.path);
        role.moveTo(role.path[role.path.length - 1].point.x, role.path[role.path.length - 1].point.y);
    };
    return UserManager;
}());
__reflect(UserManager.prototype, "UserManager");
