var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ServerTime = (function () {
    function ServerTime() {
    }
    ServerTime.prototype.init = function (serverTime) {
        this.loginServerTime = serverTime;
        this.loginLocalTime = egret.getTimer();
    };
    ServerTime.prototype.getServerTime = function () {
        return this.loginServerTime + (egret.getTimer() - this.loginLocalTime) / 1000;
    };
    return ServerTime;
}());
__reflect(ServerTime.prototype, "ServerTime");
