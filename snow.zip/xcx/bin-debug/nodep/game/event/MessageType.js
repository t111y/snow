var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var MessageType = (function () {
    function MessageType() {
    }
    MessageType.createLogin = function (name) {
        return { "msgId": 10000, "name": name };
    };
    MessageType.createEnterScene = function () {
        return { "msgId": 12000 };
    };
    MessageType.createMove = function (path) {
        return { "msgId": 12001, "path": MessageType.pathToArray(path) };
    };
    MessageType.createCirclePath = function (mesh) {
        return { "msgId": 12004, "circlePath": MessageType.pathToArray(mesh.points), "time": mesh.time };
    };
    MessageType.pathToArray = function (path) {
        var arr = new Array();
        for (var i = 0; i < path.length; i++) {
            var p = path[i];
            arr.push([Math.round(p.point.x), Math.round(p.point.y), p.time]);
        }
        return arr;
    };
    MessageType.arrayToPath = function (arr) {
        var path = new Array();
        for (var i = 0; i < arr.length; i++) {
            var p = new RolePathPoint(new egret.Point(arr[i][0], arr[i][1]));
            p.time = arr[i][2];
            path.push(p);
        }
        return path;
    };
    MessageType.createTick = function () {
        return { "msgId": 60000 };
    };
    MessageType.parseLogin = function (o) {
        var msg = new ScLogin();
        msg.playerId = o.playerId;
        return msg;
    };
    MessageType.parseEnterScene = function (o) {
        var msg = new ScEnterScene();
        msg.sceneId = o.sceneId;
        return msg;
    };
    MessageType.parseUserEnter = function (o) {
        var msg = new ScUserEnter();
        msg.players = o.players;
        return msg;
    };
    MessageType.parseMove = function (o) {
        var msg = new ScMove();
        msg.playerId = o.playerId;
        msg.path = MessageType.arrayToPath(o.path);
        ;
        return msg;
    };
    MessageType.parseCirclePath = function (o) {
        var msg = new ScCirclePath();
        msg.playerId = o.playerId;
        msg.circlePath = MessageType.arrayToPath(o.circlePath);
        msg.time = o.time;
        return msg;
    };
    MessageType.parseTick = function (o) {
        var msg = new ScTick();
        msg.time = o.time;
        return msg;
    };
    MessageType.paserScMsg = function (o) {
        switch (o.msgId) {
            case MessageType.sc_login:
                return MessageType.parseLogin(o);
            case MessageType.sc_move:
                return MessageType.parseMove(o);
            case MessageType.sc_userEnter:
                return MessageType.parseUserEnter(o);
            case MessageType.sc_circlePath:
                return MessageType.parseCirclePath(o);
            case MessageType.sc_enterScene:
                return MessageType.parseEnterScene(o);
            case MessageType.sc_tick:
                return MessageType.parseTick(o);
        }
    };
    /*
    登录
    c2s => {"msgId": 10000, "name": "test1"}
    s2c => {"msgId":10000,"playerId":429501024567297}
    */
    MessageType.sc_login = 10000;
    /*
    进入场景
    c2s => {"msgId": 12000}
    s2c => {"msgId":12000,"sceneId":6537229662358143976}
    */
    MessageType.sc_enterScene = 12000;
    /*
    同步路径(返回只发给其他玩家)
    c2s => {"msgId": 12000}
    s2c => {"msgId":12000,"sceneId":6537229662358143976}
    */
    MessageType.sc_move = 12001;
    /**
     * 别的玩家进入场景
     * s2c => {"msgId": 12002, "players": [玩家id]}
     * */
    MessageType.sc_userEnter = 12002;
    /**
     * 生成封闭区域
    c2s => {"msgId": 12004, "circlePath": [[2,3], [23, 23]....], "time": 1522296176}
    s2c => {"msgId": 12004, "playerId": 429501024567297, "time": 1522296176, "circlePath": [[2,3], [23, 23]]}
     * */
    MessageType.sc_circlePath = 12004;
    /**
     * {"msgId": 60000, "time": 1522296176}
     */
    MessageType.sc_tick = 60000;
    MessageType.playerId = "";
    return MessageType;
}());
__reflect(MessageType.prototype, "MessageType");
var ScTick = (function () {
    function ScTick() {
    }
    return ScTick;
}());
__reflect(ScTick.prototype, "ScTick");
var ScLogin = (function () {
    function ScLogin() {
    }
    return ScLogin;
}());
__reflect(ScLogin.prototype, "ScLogin");
var ScEnterScene = (function () {
    function ScEnterScene() {
    }
    return ScEnterScene;
}());
__reflect(ScEnterScene.prototype, "ScEnterScene");
var ScUserEnter = (function () {
    function ScUserEnter() {
    }
    return ScUserEnter;
}());
__reflect(ScUserEnter.prototype, "ScUserEnter");
var ScMove = (function () {
    function ScMove() {
    }
    return ScMove;
}());
__reflect(ScMove.prototype, "ScMove");
var ScCirclePath = (function () {
    function ScCirclePath() {
    }
    return ScCirclePath;
}());
__reflect(ScCirclePath.prototype, "ScCirclePath");
