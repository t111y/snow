var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var RoleAction = (function () {
    function RoleAction() {
    }
    RoleAction.RUN = "run";
    RoleAction.DROP = "drop";
    return RoleAction;
}());
__reflect(RoleAction.prototype, "RoleAction");
