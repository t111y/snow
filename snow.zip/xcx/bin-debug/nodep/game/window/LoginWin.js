var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LoginWin = (function (_super) {
    __extends(LoginWin, _super);
    function LoginWin() {
        var _this = _super.call(this) || this;
        _this.layerType = LayerType.LAYER_POP;
        _this.typeName = WorWindowType.LOGIN_WINDOW;
        return _this;
    }
    LoginWin.prototype.partAdded = function (partName, instance) {
        _super.prototype.partAdded.call(this, partName, instance);
    };
    LoginWin.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.getChildByName("txt_name").text = "user" + Math.round(Math.random() * 9999999);
        this.btn_ok = this.getChildByName("btn_ok");
        this.btn_ok.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
    };
    LoginWin.prototype.onTouchEnd = function (e) {
        this.btn_ok.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
        var txt_name = this.getChildByName("txt_name");
        Globals.i().net.send(MessageType.createLogin(txt_name.text));
        this.parent.removeChild(this);
    };
    return LoginWin;
}(GameWindow));
__reflect(LoginWin.prototype, "LoginWin", ["eui.UIComponent", "egret.DisplayObject"]);
