class RoleType {
	public static ROLE_PLAYER:string = "ROLE_PLAYER";
	public static USER_PLAYER:string = "USER_PLAYER";
	public static ROLE_NPC:string = "ROLE_NPC";
	public static ROLE_ANIMAL:string = "ROLE_ANIMAL";//动物
	public static ROLE_WILD:string = "ROLE_WILD";//野兽
	public static POLE_PLANT:string = "POLE_PLANT";
	public static PLANT_TREE:string = "TREE";//树木
	public static PLANT_COLL:string = "COLL";//采集
	public static GROUND_ITEM:string = "GROUND_ITEM";//掉落物
	public static ORE:string = "ORE";//矿物
	public static TRAP:string = "TRAP";//陷阱
}