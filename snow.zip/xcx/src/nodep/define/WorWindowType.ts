class WorWindowType extends WindowType{
    public static ROCKER_LEFT:string = "ROCKER_LEFT";//摇杆
    public static TOP_TOOLBAR:string = "TOP_TOOLBAR";//右上角导航
    public static LOG_WINDOW:string = "LOG_WINDOW";//日志任务记录界面
    public static LOGIN_WINDOW:string = "LOGIN_WINDOW";//日志任务记录界面
    public static ROLE_WINDOW:string = "ROLE_WINDOW";//左上角角色属性区
    public static MAIN_LOADING:string = "MAIN_LOADING";//游戏主加载界面
}