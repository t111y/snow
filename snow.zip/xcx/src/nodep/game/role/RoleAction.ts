class RoleAction {
	public static RUN:string = "run";
	public static DROP:string = "drop";
	public constructor() {
	}
}